const winston = require('winston');

winston.level = 'silly';

module.exports = winston;
